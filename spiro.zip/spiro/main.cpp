//
//  main.cpp
//  spirograph
//
//  Created by Philip Jung on 3/29/20.
//  Copyright © 2020 Philip Jung. All rights reserved.
//

#include <iostream>
#include <math.h>
using namespace std;
int main(int argc, const char * argv[]) {
    double R = 0.0005, r = 0.0001, a = 0.0004;
    double x0 = R+r-a, y0 = 0;
    double nRev = 10;
    cout << "Starting calculations" << endl;
    for (double t = 0.0; t < (M_PI*nRev); t+=0.01) {
        double x = (R+r)*cos((r/R)*t) - a*cos((1+r/R)*t);
        double y = (R+r)*sin((r/R)*t) - a*sin((1+r/R)*t);
        double bov_x = -118.285474;
        double bov_y = 34.020829;
        cout << to_string(x + bov_x) + "," + to_string(y + bov_y) + ",0," << endl;
    }
    return 0;
}
